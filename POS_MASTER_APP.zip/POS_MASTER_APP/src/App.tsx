function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-6">
      <div className="w-full max-w-4xl rounded-3xl border border-slate-800 bg-slate-900/60 p-12 backdrop-blur">
        <h1 className="text-4xl font-semibold tracking-tight">POS Master App</h1>
        <p className="mt-4 text-lg text-slate-300">
          Base applicative en React + TypeScript + Tailwind prête pour accueillir les vues desktop du projet.
        </p>
        <div className="mt-10 grid gap-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6">
            <h2 className="text-2xl font-medium text-slate-100">Prochaines étapes</h2>
            <ul className="mt-4 space-y-2 text-slate-300">
              <li>Ajouter le layout principal (`LayoutShell`) et les sections métiers.</li>
              <li>Importer uniquement les variantes desktop des composants existants.</li>
              <li>Intégrer les services et hooks métiers pour Facturation, Rapports, POS, Inventaire.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
